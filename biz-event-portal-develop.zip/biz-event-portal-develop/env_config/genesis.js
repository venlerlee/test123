export default {
    genesis_prefix: "/"
}