export default {
  genesis_prefix: process.env.genesis_prefix ? '/' + process.env.genesis_prefix : '/',
  current_env: 'PRD',
  biz_event_metadata:'https://bizevent.newegg.org/biz-event-metadata'
}