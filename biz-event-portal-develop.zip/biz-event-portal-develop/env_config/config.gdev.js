export default {
  genesis_prefix: process.env.genesis_prefix ? '/' + process.env.genesis_prefix : '/',
  current_env: 'GDEV',
  biz_event_metadata:'http://gdev-services.newegg.space/5b38860a'
}