## Getting started

```bash
# install dependency
npm --registry http://st01nbx01/nexus/repository/npm install

# develop
npm run dev
```