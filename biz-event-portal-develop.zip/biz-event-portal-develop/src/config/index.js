import globalConfig from 'app/config'

export default {
  env: globalConfig.current_env,
  biz_event_base: globalConfig.biz_event_metadata + "/trace/",
  // newegg_login: globalConfig.newegg_authorization_url
}