import request from '@/utils/request'
import config from '@/config'

export function get_primary_key_detail(biz_type, primary_key, is_include, fields) {
	let action = is_include ? "includes" : "excludes"
	let queryString = fields ? `?${action}=${fields}` : ""
	return request({
		url: `${config.biz_event_base}${biz_type}/${primary_key}${queryString}`,
		method: 'get'
	})
}

export function get_top_events(biz_type, from_date, to_date) {
	return request({
		url: `${config.biz_event_base}${biz_type}/${from_date}/${to_date}?size=20`,
		method: 'get'
	})
}

export function get_biz_dashboard(biz_type, biz_node, queryTime, from_date, to_date) {
	let queryString = `?last_edit_time=${queryTime}`
	if (biz_node){
		queryString += `${queryString}&biz_status=${biz_node}`
	}
	return request({
		url: `${config.biz_event_base}${biz_type}/dashboard/${from_date}/${to_date}${queryString}`,
		method: 'get'
	})
}

export function get_biz_dashboard_by_line(biz_type, biz_status, from_date, to_date) {
	let queryString = ""
	if (biz_status){
		queryString += `?biz_status=${biz_status}`
	}
	return request({
		url: `${config.biz_event_base}${biz_type}/dashboard-line/${from_date}/${to_date}${queryString}`,
		method: 'get'
	})
}


export function get_biz_part(biz_type, from_date, to_date, stauts_path, queryTime, process_time, page_size, page_index) {
	return request({
		url: `${config.biz_event_base}${biz_type}/part`,
		method: 'post',
		data: {
			'status_path': stauts_path,
			'from_date': from_date,
			'to_date': to_date,
			"page_size": page_size,
			"page_index": page_index,
			"process_time": process_time,
			"last_edit_time": queryTime == "true"
		}
	})
}

