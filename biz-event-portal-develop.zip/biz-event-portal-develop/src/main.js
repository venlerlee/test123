import Vue from 'vue'

import 'normalize.css/normalize.css' // A modern alternative to CSS resets
import  '../static/theme/walden.js'
import ElementUI from 'element-ui'
import '@/styles/index.scss' // global css

import App from './App'
import router from './router'
import store from './store'

import i18n from '@/lang'
import '@/icons' // icon
//import '@/permission' // permission control
import globalConfig from 'app/config'
import VueAnalytics from 'vue-analytics'


// Add Google Analytics support
if (globalConfig.current_env == "PRD") {
  Vue.use(VueAnalytics, {
    id: 'UA-173996047-1',
    router,
    autoTracking: {
      exception: true
    }
  })
}

import VueScreenSize from 'vue-screen-size'
Vue.use(VueScreenSize)

import JsonViewer from 'vue-json-viewer'
import 'vue-json-viewer/style.css'
import VueClipboards from 'vue2-clipboards';

Vue.use(VueClipboards);
Vue.use(JsonViewer)

Vue.use(ElementUI, {
  size: 'mini',
  i18n: (key, value) => i18n.t(key, value)
})
import moment from 'moment-timezone'
import VueMoment from 'vue-moment'

Vue.use(VueMoment, {
  moment,
})

const humanizeDuration = require('humanize-duration')

Vue.filter("formatDuration", function (epoch) {
  return humanizeDuration(epoch)
})

Vue.filter("formatChangesType", function (type) {
  if (type === 'add_table') return "success"
  else if (type === 'remove_table') return "danger"
  return ""
})

Vue.filter("formatTraceType", function (type) {
  if (type === 'NeweggSO') return "Order Phase"
  else if (type === 'OzzoSO') return "Logistics Phase"
  else if (type === 'SO') return "Order Lifecycle"
  else if (type === 'RMA') return "RMA Phase"
  else if (type === 'MPS') return "MPS Phase"
  return type
})

Vue.filter("fromatLocalDate", function (epoch) {
  if (!isNaN(epoch)) {
    return new Date(epoch).toLocaleString()
  }
  return "N/A"
})

Vue.use(ElementUI, {
  i18n: (key, value) => i18n.t(key, value)
})

Vue.config.productionTip = false

new Vue({
  el: '#app',
  router,
  store,
  i18n,
  render: h => h(App)
})