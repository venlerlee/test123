import Vue from 'vue'
import Router from 'vue-router'

import Dashborad from '@/views/dashboard/index'
import Trace from '@/views/trace/index'
import Login from '@/views/login/index'
import NotFound from '@/views/404'
import app from 'app/genesis.js'


Vue.use(Router)

/* Layout */
import Layout from '../views/layout/Layout'

/**
 * hidden: true                   if `hidden:true` will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu, whatever its child routes length
 *                                if not set alwaysShow, only more than one route under the children
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noredirect           if `redirect:noredirect` will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    title: 'title'               the name show in submenu and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar,
  }
 **/
export const constantRouterMap = [
    //     { path: '/login', component: Login, hidden: true },
    { path: '/404', component: NotFound, hidden: true },
    {
        path: '/',
        component: Layout,
        redirect: 'dashboard',
        children: [
            {
                path: 'dashboard',
                name: 'dashboard',
                meta: {
                    title: 'Dashboard',
                    icon: 'dashboard',
                    noCache:false
                },
                component: Dashborad
            },
            {
                path: 'dashboard?type=:type&stauts=:status&from_date=:from_date&to_date=:to_date&view=:view',
                name: 'dashboard',
                meta: {
                    title: 'Dashboard',
                    icon: 'dashboard',
                    noCache:false
                },
                hidden: true,
                component: Dashborad
            }
        ]
    },
    {
        path: '/',
        component: Layout,
        redirect: 'trace',
        children: [
            {
                path: 'trace',
                name: 'trace',
                meta: {
                    title: 'Trace',
                    icon: 'trace',
                    noCache:false
                },
                component: Trace
            },
            {
                path: 'trace?type=:type&pk=:pk&excludes=:excludes&includes=:includes',
                name: 'trace',
                meta: {
                    title: 'Trace',
                    icon: 'trace',
                    noCache:false
                },
                hidden: true,
                component: Trace
            }]
    }
]

export default new Router({
    mode: 'history',
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRouterMap,
    base: app.genesis_prefix
})