<template>
  <el-container style="margin: 10px">
    <el-header>
      <el-row>
        <el-col
          :offset="viewType === 'sankey' ? 2 : 4"
          :span="viewType === 'sankey' ? 22 : 20"
        >
          <el-select
            v-model="viewType"
            style="width: 90px"
            @change="onViewTypeChange"
          >
            <el-option key="sankey" label="Sankey" value="sankey"></el-option>
            <el-option key="line" label="Line" value="line"></el-option>
          </el-select>
          <span>:</span>
          <el-select v-model="bizType" @change="onViewTypeChange">
            <el-option
              v-for="item in bizTypes"
              :key="item.key"
              :label="item.label"
              :value="item.key"
            ></el-option>
          </el-select>
          <el-select
            v-model="bizNode"
            filterable
            clearable
            style="width: 600px"
            :multiple="true"
            placeholder="Status Filter"
            @change="onViewTypeChange"
          >
            <el-option
              v-for="item in bizNodes"
              :key="item.name"
              :label="item.name"
              :value="item.name"
            ></el-option>
          </el-select>
          <el-select
            v-model="queryTime"
            v-if="viewType === 'sankey'"
            style="width: 130px"
            @change="onViewTypeChange"
          >
            <el-option key="false" label="Create Date" value="false"></el-option>
            <el-option
              key="true"
              label="Update Date"
              value="true"
            ></el-option>
          </el-select>
          <el-date-picker
            :clearable="false"
            type="datetimerange"
            format="yyyy/MM/dd HH:mm"
            start-placeholder="start date"
            end-placeholder="end date"
            placeholder="select date"
            @change="onViewTypeChange"
            v-model="dateRange"
            style="width: 300px"
          ></el-date-picker>
          <el-button type="primary" @click="onViewTypeChange" :loading="loading"
            >Query</el-button
          >
          <el-tooltip content="copy link">
            <i
              class="el-icon-document-copy"
              v-clipboard="copyLink"
              @click="handleCopySuccess()"
            ></i>
          </el-tooltip>
        </el-col>
      </el-row>
    </el-header>
    <el-main style="padding: 0px">
      <div id="bizDashborad" :style="dashbordStyle"></div>
    </el-main>
    <el-backtop></el-backtop>
    <el-dialog
      width="80%"
      height="auto"
      :modal="false"
      :visible.sync="partVisible"
      :title="partTitle"
    >
      <el-row style="float: right; margin-bottom: 5px">
        <el-select
          v-model="processTime"
          filterable
          clearable
          placeholder="Process Time"
          @change="handleProcessTimeChanged"
        >
          <el-option
            v-for="item in processTimes"
            :key="item"
            :label="item"
            :value="item"
          ></el-option>
        </el-select>
        <el-button
          icon="el-icon-refresh"
          @click="handleProcessTimeChanged"
        ></el-button>
      </el-row>

      <el-table
        v-loading="partLoading"
        :data="partItems"
        border
        stripe
        style="margin-top: 5px; width: 100%"
      >
        <el-table-column label="Primary Key" width="120">
          <template slot-scope="scope">
            <el-button type="text" @click="handlePartPKClick(scope.row)">{{
              scope.row.key
            }}</el-button>
          </template>
        </el-table-column>
        <!-- <el-table-column label="In" width="180">
          <template slot-scope="scope">{{scope.row.in_time | moment('timezone', 'America/Los_Angeles', 'DD/MM/YYYY hh:mm:ss Z')}}</template>
        </el-table-column>
        <el-table-column label="Last" width="180">
          <template slot-scope="scope">{{scope.row.last_edit_time | moment('timezone', 'America/Los_Angeles', 'DD/MM/YYYY hh:mm:ss Z')}}</template>
        </el-table-column>-->
        <el-table-column label="Duration" width="180">
          <template slot-scope="scope">{{
            (scope.row.last_edit_time - scope.row.in_time) | formatDuration
          }}</template>
        </el-table-column>
        <el-table-column label="Status Trace">
          <template slot-scope="scope">
            <el-breadcrumb separator-class="el-icon-arrow-right">
              <el-breadcrumb-item
                v-for="path in scope.row.status_path"
                :key="path"
              >
                <el-tag
                  :type="partStatus.indexOf(path) > -1 ? 'success' : ''"
                  >{{ path }}</el-tag
                >
              </el-breadcrumb-item>
            </el-breadcrumb>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        slot="footer"
        @current-change="handlePartPageChanged"
        background
        layout="total, prev, pager, next"
        :current-page="page_index"
        :page-size="page_size"
        :total="total"
      ></el-pagination>
    </el-dialog>
  </el-container>
</template>
<script>
import {
  get_biz_dashboard,
  get_biz_dashboard_by_line,
  get_biz_part,
} from "@/api/biz-event";

var echarts = require("echarts");
import VueScreenSize from "vue-screen-size";
import config from "@/config";

export default {
  name: "dashboard",
  data() {
    return {
      viewType: "sankey",
      queryTime: "false",
      bizNode: "",
      bizNodes: [],
      dateRange: [],
      partTitle: "",
      partVisible: false,
      partItems: [],
      partLoading: false,
      partStatus: [],
      loading: false,
      bizTotal: 0,
      page_size: 10,
      page_index: 1,
      total: 0,
      processTime: "",
      processTimes: [
        "in 10 Seconds",
        "10-20 Seconds",
        "20-30 Seconds",
        "30-60 Seconds",
        "1-2 Minutes",
        "2-3 Minutes",
        "3-4 Minutes",
        "4-5 Minutes",
        "5-6 Minutes",
        "6-7 Minutes",
        "7-8 Minutes",
        "8-9 Minutes",
        "9-10 Minutes",
        "10-30 Minutes",
        "30-60 Minutes",
        "Over 1 Hour",
        "Over 1 Day",
      ],
      bizType: "SO",
      bizTypes: [
        {
          key: "SO",
          label: "Order Lifecycle",
        },
        {
          key: "NeweggSO",
          label: "Order Phase",
        },
        // {
        //   key: "OzzoSO",
        //   label: "Logistics Phase",
        // },
        {
          key: "MPS",
          label: "MPS Phase",
        },
        {
          key: "RMA",
          label: "RMA Phase",
        },
        // {
        //   key: "GlobalPO",
        //   label: "PO Lifecycle",
        // },
        {
          key: "PO",
          label: "PO Phase",
        },
      ],
      bizDashboardChat: null,
      dashboardOptions: {},
      copyLink: "",
    };
  },
  methods: {
    handleCopySuccess() {
      this.$message.success("share link copy to clipboard");
    },
    handlePartPageChanged(page) {
      this.page_index = page;
      this.get_parts();
    },
    handleProcessTimeChanged() {
      this.page_index = 1;
      this.get_parts();
    },
    handlePartPKClick(item) {
      this.$router.push({
        path: "trace",
        query: { type: this.bizType, pk: item.key },
      });
    },

    createChart() {
      this.bizDashboardChat = echarts.init(
        document.getElementById("bizDashborad"),
        "walden"
      );
      let self = this;
      this.bizDashboardChat.on("click", function (params) {
        if (params.data.source && params.data.target) {
          self.page_index = 1;
          self.processTime = "";
          self.get_parts(
            `${params.data.source} > ${params.data.target}`,
            `${params.data.source},${params.data.target}`
          );
        }
      });
      let chart = this.bizDashboardChat;
      window.onresize = function () {
        if (chart !== undefined) {
          chart.resize();
        }
      };
    },
    refersh() {
      this.loading = true;
      this.bizDashboardChat.showLoading();

      let from_date = this.dateRange[0].getTime();
      let to_date = this.dateRange[1].getTime();
      let status = this.bizNode ? `&status=${this.bizNode}` : "";
      this.copyLink = `${location.protocol}//${location.host}/dashboard/?type=${this.bizType}&from_date=${from_date}&to_date=${to_date}${status}&view=${this.viewType}`;

      get_biz_dashboard(
        this.bizType,
        this.bizNode,
        this.queryTime,
        from_date,
        to_date
      )
        .then((response) => {
          this.bizNodes = response.status_filter;
          this.bizDashboardChat.setOption(
            {
              title: {
                text: `${
                  this.bizTypes.find((f) => f.key == this.bizType).label
                }: ${response.total}`,
              },
              tooltip: {
                trigger: "item",
                position: "inside",
                triggerOn: "mousemove",
                confine: true,
                formatter: function (obj, ticket, callback) {
                  if (obj.data.durations == undefined) {
                    let inDatas = response.links.filter(
                      (link) => link.target == obj.name
                    );
                    let isRoot = inDatas.length == 0;
                    let outDatas = response.links.filter(
                      (link) => link.source == obj.name
                    );
                    let isEnd = outDatas.length == 0;

                    let tip = isRoot
                      ? `${obj.name}: ${obj.value} ${(
                          (obj.value / response.total) *
                          100
                        ).toFixed(2)}%`
                      : `${obj.name}: ${obj.value}`;

                    if (isRoot) {
                      tip +=
                        "<div><table><th>Out</th><th>Count</th><th>&nbsp;&nbsp;</th>";
                      let outDatas = response.links.filter(
                        (link) => link.source == obj.name
                      );
                      outDatas.sort((a, b) => b.value - a.value);
                      outDatas.forEach((link) => {
                        if (link.source == obj.name) {
                          tip += `<tr><td>${
                            link.target
                          }</td><td align="right">${
                            link.value
                          }<td/><td align="right">${(
                            (link.value / obj.value) *
                            100
                          ).toFixed(2)}%</td></tr></div>`;
                        }
                      });
                    } else {
                      tip +=
                        "<div><table style='float:left;'><th>In</th><th>Count</th><th>&nbsp;&nbsp;</th>";

                      inDatas.sort((a, b) => b.value - a.value);
                      inDatas.forEach((link) => {
                        tip += `<tr><td>${link.source}</td><td align="right">${
                          link.value
                        }<td/><td  align="right">${(
                          (link.value / obj.value) *
                          100
                        ).toFixed(2)}%</td></tr>`;
                      });
                      if (outDatas.length > 0) {
                        tip +=
                          "<table style='margin-left: 10px;float:right;'><th>Out</th><th>Count</th><th>&nbsp;&nbsp;</th>";

                        outDatas.sort((a, b) => b.value - a.value);
                        outDatas.forEach((link) => {
                          if (link.source == obj.name) {
                            tip += `<tr><td>${
                              link.target
                            }</td><td align="right">${
                              link.value
                            }<td/><td  align="right">${(
                              (link.value / obj.value) *
                              100
                            ).toFixed(2)}%</td></tr></div>`;
                          }
                        });
                      }
                    }
                    return tip;
                  }
                  if (!obj.data.durations.hasOwnProperty("tooltip")) {
                    let tip = `${obj.name}<br>Total: ${obj.data.durations.total}<table><th>Time</th><th>Count</th><th>&nbsp;&nbsp;</th>`;
                    obj.data.durations.times.forEach((element) => {
                      tip += `<tr><td>${element.key}</td><td align="right">${
                        element.count
                      }<td/><td  align="right">${(
                        (element.count / obj.data.durations.total) *
                        100
                      ).toFixed(2)}%</td></tr>`;
                    });
                    tip += "</table>";
                    obj.data.durations.tooltip = tip;
                  }

                  return obj.data.durations.tooltip;
                },
              },
              series: [
                {
                  type: "sankey",
                  layoutIterations: 1024,
                  data: response.nodes,
                  links: response.links,
                  focusNodeAdjacency: true,
                  lineStyle: {
                    curveness: 0.5,
                  },
                  label: {
                    fontFamily: "Microsoft YaHei",
                    fontSize: 10,
                  },
                },
              ],
            },
            true
          );
          this.$nextTick(function () {
            this.bizDashboardChat.resize();
          });
          this.loading = false;
          this.bizDashboardChat.hideLoading();
        })
        .catch((ex) => {
          this.$message({
            message: "get biz dashborad faild : " + ex,
            type: "error",
            duration: 5000,
          });
          this.loading = false;
          this.bizDashboardChat.hideLoading();
        });
    },
    refershByLine() {
      this.loading = true;
      this.bizDashboardChat.showLoading();

      let from_date = this.dateRange[0].getTime();
      let to_date = this.dateRange[1].getTime();
      let view = this.bizNode ? `&view=${this.viewType}` : "";
      this.copyLink = `${location.protocol}//${location.host}/dashboard/?type=${this.bizType}&from_date=${from_date}&to_date=${to_date}${status}&view=${this.viewType}`;

      get_biz_dashboard_by_line(this.bizType, this.bizNode, from_date, to_date)
        .then((response) => {
          let data = this.formatSeries(response.status);
          this.bizNodes = response.status_filter;
          let options = {
            grid: {
              left: "3%",
              right: "4%",
              bottom: "20%",
              containLabel: true,
            },
            tooltip: {
              trigger: "axis",
            },
            legend: {
              data: data.legend,
              top: "bottom",
            },
            xAxis: {
              splitNumber: 24,
              type: "time",
              boundaryGap: false,
              splitLine: {
                show: false,
              },
            },
            yAxis: {
              boundaryGap: false,
              type: "value",
              minInterval: 1,
              name: "Total : " + response.total,
            },
            series: data.series,
          };
          this.bizDashboardChat.setOption(options, true);
          this.$nextTick(function () {
            this.bizDashboardChat.resize();
          });
          this.loading = false;
          this.bizDashboardChat.hideLoading();
        })
        .catch((ex) => {
          this.$message({
            message: "get biz dashborad faild : " + ex,
            type: "error",
            duration: 5000,
          });
          this.loading = false;
          this.bizDashboardChat.hideLoading();
        });
    },
    onViewTypeChange() {
      if (this.viewType === "line") this.refershByLine();
      else this.refersh();
    },
    formatSeries(statusList) {
      let result = {
        series: [],
        legend: [],
      };
      if (!statusList || statusList.length == 0) return {};
      statusList.forEach((status, index) => {
        let data = {
          name: status.name,
          type: "line",
          smooth: true,
          data: Array.from(status.hours, (item) => [
            new Date(item.key),
            item.doc_count,
          ]),
          symbol: "none",
          areaStyle: {
            normal: {},
          },
        };
        result.series.push(data);
        result.legend.push(status.name);
      });
      return result;
    },
    get_parts(title, partPath) {
      this.partLoading = true;
      this.partVisible = true;
      if (title) this.partTitle = title;
      if (partPath) this.partPath = partPath;
      this.partStatus = this.partPath.split(",");
      get_biz_part(
        this.bizType,
        this.dateRange[0].getTime(),
        this.dateRange[1].getTime(),
        this.partPath,
        this.queryTime,
        this.processTime,
        this.page_size,
        this.page_index
      )
        .then((response) => {
          this.partItems = response.items;
          this.total = response.total;
          this.partLoading = false;
        })
        .catch((error) => {
          this.partLoading = false;
          this.$message.error(`get part trace faild. ${error}`);
        });
    },
    getDefaultDateRange() {
      let startDate = new Date();
      startDate.setHours(0);
      startDate.setMinutes(0);
      startDate.setSeconds(0);
      let endDate = new Date();
      endDate.setDate(startDate.getDate() + 1);
      endDate.setHours(0);
      endDate.setMinutes(0);
      endDate.setSeconds(0);

      return [startDate, endDate];
    },
  },
  computed: {
    dashbordStyle: function () {
      return `height: ${this.$vssHeight - 165}px; width: 100%`;
    },
  },
  mounted() {
    this.createChart();
    if (
      this.$route.query &&
      this.$route.query.type &&
      this.$route.query.from_date &&
      this.$route.query.to_date &&
      this.$route.query.view
    ) {
      this.bizType = this.$route.query.type;
      this.dateRange = [
        new Date(parseInt(this.$route.query.from_date)),
        new Date(parseInt(this.$route.query.to_date)),
      ];
      if (this.$route.query.status) this.bizNode = this.$route.query.status;
      this.viewType = this.$route.query.view;
    } else {
      this.dateRange = this.getDefaultDateRange();
    }
    this.onViewTypeChange();
  },
  mixins: [VueScreenSize.VueScreenSizeMixin],
};
</script>

<style></style>
