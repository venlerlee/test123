<template>
  <el-container style="margin: 10px">
    <el-header>
      <el-row :gutter="10">
        <el-col :offset="4" :span="10">
          <el-input v-model="pk" ref="pkInput" @keyup.enter.native="getPrimaryDetail" clearable>
            <template slot="prepend">
              <el-select v-model="traceBizType" style="width: 220px">
                <el-option
                  v-for="item in traceBizTypes"
                  :key="item.key"
                  :label="item.label"
                  :value="item.key"
                ></el-option>
              </el-select>
            </template>
          </el-input>
        </el-col>
        <el-col :span="10">
          <el-button
            type="primary"
            :disabled="pk.length == 0"
            :loading="loading"
            @click="getPrimaryDetail"
          >Search</el-button>
          <el-tooltip content="copy link">
            <i class="el-icon-document-copy" v-clipboard="copyLink" @click="handleCopySuccess()"></i>
          </el-tooltip>
        </el-col>
      </el-row>
      <el-row :gutter="10" style="margin-top: 5px">
        <el-col :offset="4" :span="10">
          <el-input
            v-model="fields"
            placeholder="LastEditDate,LastEditUser,..."
            @keyup.enter.native="getPrimaryDetail"
            clearable
          >
            <template slot="prepend">
              <el-switch v-model="isInclude" active-text="Include" inactive-text="Exclude"></el-switch>
            </template>
          </el-input>
        </el-col>
        <el-col :span="10">
          <el-button :loading="findToploading" @click="getTopEvents">Top Events</el-button>
        </el-col>
      </el-row>
    </el-header>
    <el-main>
      <el-table
        v-loading="loading"
        :data="items"
        border
        stripe
        :default-sort="{prop: 'EventTime', order: 'ascending'}"
      >
        <el-table-column type="expand">
          <template slot-scope="scope">
            <el-tabs type="border-card" v-if="scope.row.Changes.length > 0">
              <el-tab-pane
                :label="change.Table"
                v-for="(change, index) in scope.row.Changes"
                :key="index"
              >
                <el-table v-if="change.Type === 'values'" :data="change.Changes" border stripe>
                  <el-table-column label="Key">
                    <template slot-scope="scope">{{scope.row.key}}</template>
                  </el-table-column>
                  <el-table-column label="Before">
                    <template slot-scope="scope">
                      <strong style="color: #DD6161;">{{ scope.row.old_value}}</strong>
                    </template>
                  </el-table-column>
                  <el-table-column label="After">
                    <template slot-scope="scope">
                      <strong style="color: #8CC5FF;">{{ scope.row.new_value}}</strong>
                    </template>
                  </el-table-column>
                </el-table>
                <span v-else-if="change.Type === 'add_table'">Added</span>
                <span v-else-if="change.Type === 'remove_table'">Removed</span>
                <el-table v-else :data="change.Changes" border stripe>
                  <el-table-column label="Key">
                    <template slot-scope="scope">
                      <span v-if="scope.row.before">items</span>
                      <span v-else>{{scope.row.key}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="Before">
                    <template slot-scope="scope">
                      <div v-if="scope.row.before">
                        <el-tag
                          v-for="(item, index) in scope.row.before"
                          :key="index"
                          style="margin-right: 5px;"
                          :type="bizChangeType(item[change.unique_key], scope.row.added_changes, scope.row.removed_changes)"
                          @click="handleChangeDetail(item)"
                        >{{item[change.alt_key]}}</el-tag>
                      </div>
                      <div v-else>
                        <strong style="color: #DD6161;">{{ scope.row.old_value}}</strong>
                      </div>
                    </template>
                  </el-table-column>
                  <el-table-column label="After">
                    <template slot-scope="scope">
                      <div v-if="scope.row.before">
                        <el-tag
                          v-for="(item, index) in scope.row.after"
                          :key="index"
                          style="margin-right: 5px;"
                          :type="bizChangeType(item[change.unique_key], scope.row.added_changes, scope.row.removed_changes)"
                          @click="handleChangeDetail(item)"
                        >{{item[change.alt_key]}}</el-tag>
                      </div>
                      <div v-else>
                        <strong style="color: #8CC5FF;">{{ scope.row.new_value}}</strong>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </el-tab-pane>
            </el-tabs>
            <span v-else>N/A</span>
          </template>
        </el-table-column>
        <el-table-column type="index" width="50"></el-table-column>
        <el-table-column label="Biz Type" width="120" v-if="traceType === 'GlobalKeyType'">
          <template slot-scope="scope">{{scope.row.Type | formatTraceType}}</template>
        </el-table-column>
        <el-table-column label="Biz Status" width="260">
          <template slot-scope="scope">{{scope.row.BusinessStatus}}</template>
        </el-table-column>
        <el-table-column label="Change Tables">
          <template slot-scope="scope">
            <el-tag
              style="margin-right: 5px;"
              v-for="(change, index) in scope.row.Changes"
              :key="index"
              :type="change.Type | formatChangesType"
            >{{change.Table}}</el-tag>
            <span v-if="scope.row.Changes.length == 0">N/A</span>
          </template>
        </el-table-column>
        <el-table-column label="Duration" width="180">
          <template slot-scope="scope">{{ scope.row.Duration | formatDuration }}</template>
        </el-table-column>
        <el-table-column sortable prop="EventTime" label="EventTime" width="200">
          <template
            slot-scope="scope"
          >{{ scope.row.EventTime | moment('timezone', 'America/Los_Angeles', 'DD/MM/YYYY HH:mm:ss Z')}}</template>
        </el-table-column>
        <el-table-column label="Link Tables" width="100" fixed="right">
          <template slot-scope="scope">
            <el-button @click="handleDetail(scope.row)">Tables</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog
        title="ChangeDetail"
        :visible.sync="dialogChangeVisible"
        @closed="dialogChangeVisible = false"
      >
        <JsonViewer :value="currentEventChangeItem" />
      </el-dialog>
      <el-dialog title="Detail" :visible.sync="dialogVisible" @closed="dialogVisible = false">
        <JsonViewer :value="currentEvent.LinkTable" />
      </el-dialog>
      <el-drawer
        title="Top 20 Events"
        :visible.sync="drawer"
        direction="rtl"
        @closed="drawer = false"
      >
        <el-row style="margin: 5px" :gutter="10" type="flex">
          <el-date-picker
            :clearable="false"
            type="datetimerange"
            format="yyyy/MM/dd"
            start-placeholder="start date"
            end-placeholder="end date"
            placeholder="select date"
            @change="refershTopEvents"
            v-model="dateRange"
            style="width: 220px; margin-right: 5px"
          ></el-date-picker>
          <el-button type="primary" @click="refershTopEvents">Search</el-button>
        </el-row>
        <el-table :data="primary_keys" border stripe style="margin: 5px" v-loading="findToploading">
          <el-table-column prop="key" label="Prmary Key" width="160">
            <template slot-scope="scope">
              <el-button
                type="primary"
                @click="getPrimaryDetailFromTop(scope.row.key)"
              >{{ scope.row.key}}</el-button>
            </template>
          </el-table-column>
          <el-table-column label="Count" width="80">
            <template slot-scope="scope">{{ scope.row.doc_count}}</template>
          </el-table-column>
        </el-table>
      </el-drawer>
    </el-main>
    <el-backtop></el-backtop>
  </el-container>
</template>

<script>
import { get_primary_key_detail, get_top_events } from "@/api/biz-event";

import JsonViewer from "vue-json-viewer";

export default {
  name: "trace",
  data() {
    return {
      isInclude: false,
      fields: "",
      copyLink: "",
      drawer: false,
      dialogChangeVisible: false,
      findToploading: false,
      currentEvent: {
        LinkTable: {},
      },
      currentEventChangeItem: {},
      dialogVisible: false,
      loading: false,
      pk: "",
      items: [],
      traceType: "",
      total: 0,
      traceBizType: "NeweggSO",
      traceBizTypes: [
        {
          key: "SO",
          label: "Order Lifecycle (SO#)",
        },
        {
          key: "NeweggSO",
          label: "Order Phase (SO#)",
        },
        // {
        //   key: "OzzoSO",
        //   label: "Logistics Phase (DropShipID)",
        // },
        {
          key: "MPS",
          label: "MPS Phase (SO#)",
        },
        {
          key: "RMA",
          label: "RMA Phase (RMA#)",
        },
        // {
        //   key: "GlobalPO",
        //   label: "PO Lifecycle",
        // },
        {
          key: "PO",
          label: "PO Phase (PO#)",
        },
        {
          key: "ItemReview",
          label: "Item Review (Review ID)",
        },
        {
          key: "WishList",
          label: "Wish List (WishList#)",
        },
      ],
      primary_keys: [],
      dateRange: [],
    };
  },
  components: {
    JsonViewer,
  },
  methods: {
    refershTopEvents() {
      this.getTopEvents();
    },
    handleCopySuccess() {
      this.$message.success("share link copy to clipboard");
    },
    getTopEvents() {
      this.findToploading = true;
      get_top_events(
        this.traceBizType,
        this.dateRange[0].getTime(),
        this.dateRange[1].getTime()
      )
        .then((response) => {
          this.findToploading = false;
          this.drawer = true;
          this.primary_keys = response.primary_keys;
        })
        .catch((error) => {
          this.findToploading = false;
          this.$message.error(error);
        });
    },
    handleChangeDetail(item) {
      this.currentEventChangeItem = item;
      this.dialogChangeVisible = true;
    },
    handleDetail(event) {
      this.currentEvent = event;
      this.dialogVisible = true;
    },
    getPrimaryDetailFromTop(pk) {
      this.pk = pk;
      this.drawer = false;
      this.getPrimaryDetail();
    },
    getPrimaryDetail() {
      this.loading = true;
      let action = this.isInclude ? "includes" : "excludes";
      let queryString = this.fields ? `&${action}=${this.fields}` : "";
      this.copyLink = `${location.protocol}//${location.host}/trace/?type=${this.traceBizType}&pk=${this.pk}${queryString}`;

      get_primary_key_detail(
        this.traceBizType,
        this.pk,
        this.isInclude,
        this.fields
      )
        .then((response) => {
          this.loading = false;
          this.total = response.total;
          this.items = response.items;
          this.traceType = response.type;
        })
        .catch((error) => {
          this.loading = false;
          this.$message.error(error);
        });
    },
    bizChangeType(key, add_keys, removed_keys) {
      let is_add = add_keys.find((k) => k === key);
      if (is_add !== undefined) {
        return "success";
      }
      let is_removed = removed_keys.find((k) => k === key);
      return is_removed ? "danger" : "info";
    },
    getDefaultDateRange() {
      let endDate = new Date();
      endDate.setDate(endDate.getDate() + 1);
      endDate.setHours(0);
      endDate.setMinutes(0);
      endDate.setSeconds(0);
      let startDate = new Date();
      startDate.setDate(startDate.getDate() - 3);
      startDate.setHours(0);
      startDate.setMinutes(0);
      startDate.setSeconds(0);

      return [startDate, endDate];
    },
  },
  mounted() {
    this.$refs.pkInput.$refs.input.focus();
    this.dateRange = this.getDefaultDateRange();
    if (this.$route.query && this.$route.query.type && this.$route.query.pk) {
      this.traceBizType = this.$route.query.type;
      this.pk = this.$route.query.pk;
      if (this.$route.query.excludes) {
        this.isInclude = false;
        this.fields = this.$route.query.excludes;
      } else if (this.$route.query.includes) {
        this.isInclude = true;
        this.fields = this.$route.query.includes;
      }
      this.getPrimaryDetail();
    }
  },
};
</script>

<style></style>
